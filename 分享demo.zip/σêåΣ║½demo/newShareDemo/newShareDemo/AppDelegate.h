//
//  AppDelegate.h
//  newShareDemo
//
//  Created by 张晴顺 on 2017/9/13.
//  Copyright © 2017年 刘文超. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

